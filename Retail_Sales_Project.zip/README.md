# Retail Sales Data Analysis and Sales Prediction

Objective:
Analyze retail sales data, visualize trends, and build a simple sales prediction model.

Files:
- retail_sales_project.py
- project_report.txt
