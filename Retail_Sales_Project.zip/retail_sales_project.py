
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

df = pd.read_csv('superstore.csv')

df.drop_duplicates(inplace=True)
df['Order Date'] = pd.to_datetime(df['Order Date'])

sales_category = df.groupby('Category')['Sales'].sum()
sales_category.plot(kind='bar')
plt.show()

df['Month'] = df['Order Date'].dt.month
monthly_sales = df.groupby('Month')['Sales'].sum()
monthly_sales.plot(kind='line', marker='o')
plt.show()

X = df[['Profit']]
y = df['Sales']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)

predictions = model.predict(X_test)
print(predictions[:5])
